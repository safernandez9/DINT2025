package dint1.ComponentesGraficos.JRadioButton;

class Camiseta {
        String logotipo;
        boolean mangaLonga;
        int cor;
        int material;

    Camiseta(String logotipo, boolean mangaLonga) {
        this.logotipo = logotipo;
        this.mangaLonga = mangaLonga;
    }
    
    void setMaterial(int i) {
        material = i;
    }

    void setCor(int cor) {
        this.cor = cor;
    }

    @Override
    public String toString() {
        return "Camiseta{" + "logotipo=" + logotipo + ", mangaLonga=" + mangaLonga + ", cor=" + cor + ", material=" + material + '}';
    }      
        
    }
